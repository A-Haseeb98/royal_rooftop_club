import "./App.css";
import Config from "./config/Config";
import HomePage from "./pages/homePage/HomePage";
function App() {
  return (
    <div className="App">
      <Config />
    </div>
  );
}

export default App;
